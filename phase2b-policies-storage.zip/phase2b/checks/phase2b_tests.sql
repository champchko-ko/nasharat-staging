-- Phase 2b policy tests. Run in the Supabase SQL Editor AFTER applying 0014 and 0015.
-- The script switches between real database roles (anon / authenticated) so row
-- level security is genuinely applied. Everything runs inside a transaction that
-- is rolled back at the end; no data is left behind. A failure raises "FAILED: ...".
begin;

create schema t_tmp;
grant usage on schema t_tmp to public;

create function t_tmp.as_service() returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
end $$;

create function t_tmp.as_user(u uuid) returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u::text, true);
  execute 'set local role authenticated';
end $$;

create function t_tmp.as_anon() returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  execute 'set local role anon';
end $$;

create function t_tmp.cnt(q text) returns integer language plpgsql as $$
declare n integer;
begin
  execute 'select count(*) from (' || q || ') x' into n;
  return n;
end $$;

create function t_tmp.fails(q text) returns boolean language plpgsql as $$
begin
  execute q;
  return false;
exception when others then
  return true;
end $$;

create function t_tmp.changed(q text) returns integer language plpgsql as $$
declare n integer;
begin
  execute q;
  get diagnostics n = row_count;
  return n;
end $$;

create function t_tmp.expect(c boolean, msg text) returns void language plpgsql as $$
begin
  if not coalesce(c, false) then raise exception 'FAILED: %', msg; end if;
end $$;

grant execute on all functions in schema t_tmp to public;

do $$
declare
  u_owner uuid := gen_random_uuid();
  u_admin uuid := gen_random_uuid();
  u_teacher uuid := gen_random_uuid();
  u_head uuid := gen_random_uuid();
  u_headb uuid := gen_random_uuid();
  u_tech uuid := gen_random_uuid();
  u_x1 uuid := gen_random_uuid();
  u_x2 uuid := gen_random_uuid();
  d_a uuid := gen_random_uuid();
  d_b uuid := gen_random_uuid();
  c_int uuid := gen_random_uuid();
  c_pub uuid := gen_random_uuid();
  c_draft uuid := gen_random_uuid();
  m_1 uuid := gen_random_uuid();
  m_2 uuid := gen_random_uuid();
  r_owner uuid; r_admin uuid; r_head uuid; r_staff uuid; r_op uuid;
begin
  -- ===== Fixtures, in a trusted (service) context. Static SQL only up to the first role switch.
  select id into r_owner from public.roles where key = 'owner';
  select id into r_admin from public.roles where key = 'school_admin';
  select id into r_head from public.roles where key = 'department_head';
  select id into r_staff from public.roles where key = 'staff';
  select id into r_op from public.roles where key = 'operator';

  insert into auth.users (id, aud, role, email)
  select x, 'authenticated', 'authenticated', 't_' || x || '@test.local'
  from unnest(array[u_owner, u_admin, u_teacher, u_head, u_headb, u_tech, u_x1, u_x2]) as x;
  insert into public.profiles (id, full_name, email)
  select x, 'User ' || left(x::text, 6), 't_' || x || '@test.local'
  from unnest(array[u_owner, u_admin, u_teacher, u_head, u_headb, u_tech, u_x1, u_x2]) as x;

  insert into public.departments (id, name_ar, name_en) values (d_a, 'أ', 'A'), (d_b, 'ب', 'B');

  -- The owner chooses every role's permissions; the test plays that part.
  insert into public.role_permissions (role_id, permission_key)
  select r_admin, k from unnest(array['circular.create','circular.publish','circular.view_responses',
    'maintenance.assign','maintenance.close','calendar.manage','settings.school.update',
    'users.manage','reports.view','audit.view']) as k;
  insert into public.role_permissions (role_id, permission_key)
  select r_head, k from unnest(array['circular.respond','circular.view_responses','maintenance.create']) as k;
  insert into public.role_permissions values (r_staff, 'maintenance.create'), (r_op, 'maintenance.update');

  insert into public.user_role_assignments (user_id, role_id, department_id) values
    (u_owner, r_owner, null), (u_admin, r_admin, null), (u_tech, r_op, null),
    (u_teacher, r_staff, d_a), (u_head, r_head, d_a), (u_headb, r_head, d_b);

  insert into public.circulars (id, ref_number, title, body, created_by, status, visibility) values
    (c_int, 'T-INT', 'internal', 'b', u_admin, 'published', 'internal'),
    (c_pub, 'T-PUB', 'public', 'b', u_admin, 'published', 'public'),
    (c_draft, 'T-DRAFT', 'draft', 'b', u_admin, 'draft', 'internal');
  insert into public.circular_targets (circular_id, department_id) values (c_int, d_a);

  insert into public.calendar_events (title_ar, starts_at, ends_at, created_by, status, visibility) values
    ('pub', now(), now(), u_admin, 'published', 'public'),
    ('int', now(), now(), u_admin, 'published', 'internal'),
    ('draft', now(), now(), u_admin, 'draft', 'public');
  insert into public.school_achievements (title_ar, created_by, visibility) values
    ('pub', u_admin, 'public'), ('int', u_admin, 'internal');
  insert into public.school_documents (slug, title, file_path, file_name, status, visibility, created_by) values
    ('operational-plan', 'pub', 'operational-plan/pub.pdf', 'pub.pdf', 'published', 'public', u_admin),
    ('operational-plan', 'int', 'operational-plan/int.pdf', 'int.pdf', 'published', 'internal', u_admin);

  insert into public.maintenance_requests (id, ticket_number, title, description, reporter_id)
    values (m_1, 'MR-T-1', 't', 'd', u_teacher);

  insert into public.notifications (user_id, title) values (u_teacher, 'n1'), (u_admin, 'n2');
  insert into public.backup_snapshots (payload) values ('{}'::jsonb);

  insert into public.circular_attachments (circular_id, path, uploaded_by) values
    (c_pub, c_pub || '/a.pdf', u_admin), (c_int, c_int || '/b.pdf', u_admin);
  insert into storage.objects (bucket_id, name) values
    ('public-assets', 'logo/x.png'),
    ('circular-attachments', c_pub || '/a.pdf'),
    ('circular-attachments', c_int || '/b.pdf'),
    ('school-documents', 'operational-plan/pub.pdf'),
    ('school-documents', 'operational-plan/int.pdf');

  -- ===== From here on, only perform t_tmp.* calls (the session role changes).

  -- ANONYMOUS VISITOR: public, published content only
  perform t_tmp.as_anon();
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circulars') = 1, 'anon sees only the public published circular');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.calendar_events') = 1, 'anon sees only the public published event');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.school_documents') = 1, 'anon sees only the public published document');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.school_achievements') = 1, 'anon sees only the public achievement');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.public_school_profiles') = 1, 'anon reads the school profile view');
  perform t_tmp.expect(t_tmp.fails('select 1 from public.maintenance_requests'), 'anon cannot read maintenance');
  perform t_tmp.expect(t_tmp.fails('select 1 from public.profiles'), 'anon cannot read profiles');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'public-assets'$q$) = 1, 'anon reads public assets');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'circular-attachments'$q$) = 1, 'anon reads only the public circular attachment');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'school-documents'$q$) = 1, 'anon reads only the public document file');

  -- TEACHER (staff, department A, only maintenance.create)
  perform t_tmp.as_user(u_teacher);
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circulars') = 2, 'teacher sees the public circular and the one targeted at their department');
  perform t_tmp.expect(t_tmp.fails(format($q$insert into public.circulars (ref_number, title, body, created_by) values ('T-X','t','b',%L)$q$, u_teacher)), 'teacher cannot create a circular');
  perform t_tmp.expect(t_tmp.changed(format($q$update public.circulars set title = 'x' where id = %L$q$, c_int)) = 0, 'teacher cannot edit a circular');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.maintenance_requests') = 1, 'teacher sees their own request');
  perform t_tmp.expect(t_tmp.fails(format($q$update public.maintenance_requests set title = 'x' where id = %L$q$, m_1)), 'reporter cannot edit their request');
  perform t_tmp.expect(not t_tmp.fails(format($q$insert into public.maintenance_requests (id, ticket_number, title, description, reporter_id) values (%L,'MR-T-2','t','d',%L)$q$, m_2, u_teacher)), 'teacher can report a problem');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.roles') = 0, 'teacher cannot read roles');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.permissions') = 16, 'teacher can read the permission catalogue');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.audit_logs') = 0, 'teacher cannot read the audit log');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.notifications') = 1, 'teacher sees only their notification');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.backup_snapshots') = 0, 'teacher cannot read backups');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.calendar_events') = 2, 'teacher sees published events, not drafts');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.school_documents') = 2, 'teacher sees published documents');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.school_achievements') = 2, 'teacher sees all achievements');
  perform t_tmp.expect(t_tmp.fails($q$insert into public.calendar_events (title_ar, starts_at, ends_at, created_by) values ('x', now(), now(), (select auth.uid()))$q$), 'teacher cannot create events');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'circular-attachments'$q$) = 2, 'teacher reads attachments of circulars aimed at them');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'school-documents'$q$) = 2, 'teacher reads published document files');

  -- DEPARTMENT HEAD A (respond + view responses, bound to department A)
  perform t_tmp.as_user(u_head);
  perform t_tmp.expect(not t_tmp.fails(format($q$insert into public.circular_responses (circular_id, department_id, responder_id, response_type) values (%L,%L,%L,'acknowledgement')$q$, c_int, d_a, u_head)), 'department head can respond for their department');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circular_responses') = 1, 'department head sees their department response');

  -- DEPARTMENT HEAD B (same role, other department)
  perform t_tmp.as_user(u_headb);
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circulars') = 1, 'a department-bound view_responses holder does not see every circular');
  perform t_tmp.expect(t_tmp.fails(format($q$insert into public.circular_responses (circular_id, department_id, responder_id, response_type) values (%L,%L,%L,'acknowledgement')$q$, c_int, d_a, u_headb)), 'department head B cannot respond for department A');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circular_responses') = 0, 'department head B cannot see department A responses');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from storage.objects where bucket_id = 'circular-attachments'$q$) = 1, 'department head B reads only the public circular attachment');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.maintenance_requests') = 0, 'department head B sees no maintenance by default');

  -- SCHOOL ADMIN (granted ten permissions by the test)
  perform t_tmp.as_user(u_admin);
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circulars') = 3, 'admin sees all circulars (school-wide view_responses and creator)');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.circular_responses') = 1, 'admin sees responses');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.maintenance_requests') = 2, 'admin sees all maintenance requests');
  perform t_tmp.expect(not t_tmp.fails(format($q$insert into public.maintenance_assignments (request_id, operator_id, assigned_by) values (%L,%L,%L)$q$, m_1, u_tech, u_admin)), 'admin can assign a technician');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.roles where key = 'owner'$q$) = 0, 'admin cannot see the owner role');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.roles') = 4, 'admin sees the four other system roles');
  perform t_tmp.expect(t_tmp.fails($q$insert into public.roles (key, name_ar, name_en) values ('x_role', 'x', 'x')$q$), 'admin cannot create roles');
  perform t_tmp.expect(t_tmp.fails(format($q$insert into public.role_permissions values (%L, 'audit.view')$q$, r_staff)), 'admin cannot change role permissions');
  perform t_tmp.expect(not t_tmp.fails(format($q$insert into public.user_role_assignments (user_id, role_id) values (%L,%L)$q$, u_x1, r_op)), 'admin can assign an existing role');
  perform t_tmp.expect(t_tmp.fails(format($q$insert into public.user_role_assignments (user_id, role_id) values (%L,%L)$q$, u_x2, r_owner)), 'admin cannot assign the owner role');
  perform t_tmp.expect(not t_tmp.fails(format($q$insert into public.calendar_events (title_ar, starts_at, ends_at, created_by, status, visibility) values ('new', now(), now(), %L, 'published', 'public')$q$, u_admin)), 'admin can publish a public event');
  perform t_tmp.expect(t_tmp.changed($q$update public.schools set name_en = 'Test School'$q$) = 1, 'admin can edit the school profile');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.audit_logs') > 0, 'admin can read the audit log');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.notifications') = 1, 'admin sees only their own notification');

  -- MAINTENANCE TECHNICIAN
  perform t_tmp.as_user(u_tech);
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.maintenance_requests') = 1, 'technician sees only the request assigned to them');

  -- OWNER
  perform t_tmp.as_user(u_owner);
  perform t_tmp.expect(not t_tmp.fails($q$insert into public.roles (key, name_ar, name_en) values ('electrician', 'كهربائي', 'Electrician')$q$), 'owner can create a role');
  perform t_tmp.expect(not t_tmp.fails($q$insert into public.role_permissions select id, 'maintenance.update' from public.roles where key = 'electrician'$q$), 'owner can choose its permissions');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.roles where key = 'owner'$q$) = 1, 'owner sees the owner role');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.backup_snapshots') = 1, 'owner can read backups');
  perform t_tmp.expect(not t_tmp.fails($q$insert into public.system_settings (key, value) values ('t', '{}')$q$), 'owner can write system settings');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.maintenance_requests') = 2, 'owner sees everything');

  perform t_tmp.as_service();
end $$;

select 'phase 2b policy tests passed' as result;
rollback;
