# Phase 2b: row-level security policies, storage, public view

Adds migrations 0014 and 0015 on top of Phases 1 and 2a.

| File | What it adds |
|---|---|
| 0014_rls_policies.sql | `has_school_wide_permission`, all table policies (91 policies across all tables), anonymous access limited to five tables, realtime for notifications |
| 0015_storage_and_public_view.sql | Four storage buckets (documents bucket is now private), "may I read this file" checks, storage policies, `public_school_profiles` view without timezone |

## Storage path layout (code changes come in a later phase)

| Bucket | Old path | New path |
|---|---|---|
| circular-attachments | `<school_id>/<circular_id>/<file>` | `<circular_id>/<file>` |
| maintenance-photos | `<school_id>/<request_id>/<file>` | `<request_id>/<file>` |
| public-assets | `<school_id>/logo/...`, `<school_id>/calendar/...` | `logo/<file>`, `calendar/<file>` |
| school-documents | `<school_id>/<slug>/<file>` | `<slug>/<file>` |

`school-documents` was a public bucket. It is private now so an internal document's
file cannot be opened by anyone who has the link. Code that built public URLs for
documents must use signed URLs or a server route (done in the code phase).

## Apply (PowerShell, in claude_nasharat)

```powershell
Expand-Archive .\phase2b-policies-storage.zip -DestinationPath .\_phase2b -Force
Copy-Item .\_phase2b\phase2b\supabase\migrations\*.sql .\supabase\migrations\
$env:SUPABASE_DB_PASSWORD = 'your-database-password'
supabase db push
```

## Test

Paste `_phase2b\phase2b\checks\phase2b_tests.sql` into the Supabase SQL Editor and run it.
Expected: `phase 2b policy tests passed`. It rolls back and leaves no data.
On failure, send the full error text (it starts with `FAILED`).

## Then

```powershell
Remove-Item .\_phase2b -Recurse -Force
git add -A
git commit -m "Phase 2b: RLS policies, storage, public view"
git push
```

The SQL has not been executed by me; it was checked statically only.
