# Phase 2c: remaining functions, demo seed, function tests

| File | What it is |
|---|---|
| supabase/migrations/0016_remaining_functions.sql | submit_circular_response, dissociate_school_user, restore_backup_auth_users, restore_backup (single-school versions) |
| supabase/seed.sql | Demo data for LOCAL development only (replaces the Phase 1 placeholder) |
| checks/phase2c_tests.sql | Behaviour tests for 0016 (rolls back, leaves no data) |

## Changes from the multi-tenant versions

- `submit_circular_response(circular, department, type, status, reason)`: no school argument.
- `dissociate_school_user(user)`: removes the role, clears the department and deactivates the account; the profile row stays. The "last school administrator" guard is gone (decided earlier).
- `restore_backup(tables, actor)`: no scope or school argument; callable by the service role only.
  - the school and its settings are replaced in place (single rows);
  - roles are matched by key; system roles keep their ids and flags; role ids inside
    role_permissions and user_role_assignments are remapped, so a backup restores into a
    freshly built project;
  - a backup can never create or change the owner role, an owner assignment or an owner account;
  - department heads are linked after profiles are restored.

## Apply (PowerShell, in claude_nasharat)

```powershell
Expand-Archive .\phase2c-functions-seed.zip -DestinationPath .\_phase2c -Force
Copy-Item .\_phase2c\phase2c\supabase\migrations\*.sql .\supabase\migrations\
Copy-Item .\_phase2c\phase2c\supabase\seed.sql .\supabase\seed.sql -Force
$env:SUPABASE_DB_PASSWORD = 'your-database-password'
supabase db push
```

`supabase db push` applies only the migration. The demo seed runs only on a local stack
(`supabase db reset`), never on your hosted project.

## Test

Paste `_phase2c\phase2c\checks\phase2c_tests.sql` into the Supabase SQL Editor and run it.
Expected: `phase 2c function tests passed`.

## Then

```powershell
Remove-Item .\_phase2c -Recurse -Force
git add -A
git commit -m "Phase 2c: remaining functions, demo seed"
git push
```

## Not in this package (stated plainly)

The old Node RLS suite in `supabase/tests/` is written for the multi-tenant schema and will
not pass against the new database. Rewriting it needs the local Docker stack and the
rewritten app code, so it moves to the code phase. In the meantime the SQL tests from
Phases 2a, 2b and 2c are the RLS test suite for the new schema.

The SQL has not been executed by me; it was checked statically only.
