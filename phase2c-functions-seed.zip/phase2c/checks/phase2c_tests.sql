-- Phase 2c function tests. Run in the Supabase SQL Editor AFTER applying 0016.
-- Runs inside a transaction that is rolled back at the end, so no data is left
-- behind. A failure raises "FAILED: ...".
begin;

create schema t_tmp;
grant usage on schema t_tmp to public;

create function t_tmp.as_service() returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
end $$;

create function t_tmp.as_user(u uuid) returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u::text, true);
  execute 'set local role authenticated';
end $$;

create function t_tmp.as_anon() returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  execute 'set local role anon';
end $$;

create function t_tmp.cnt(q text) returns integer language plpgsql as $$
declare n integer;
begin
  execute 'select count(*) from (' || q || ') x' into n;
  return n;
end $$;

create function t_tmp.fails(q text) returns boolean language plpgsql as $$
begin
  execute q;
  return false;
exception when others then
  return true;
end $$;

create function t_tmp.changed(q text) returns integer language plpgsql as $$
declare n integer;
begin
  execute q;
  get diagnostics n = row_count;
  return n;
end $$;

create function t_tmp.expect(c boolean, msg text) returns void language plpgsql as $$
begin
  if not coalesce(c, false) then raise exception 'FAILED: %', msg; end if;
end $$;

grant execute on all functions in schema t_tmp to public;


do $$
declare
  u_owner uuid := gen_random_uuid();
  u_admin uuid := gen_random_uuid();
  u_teacher uuid := gen_random_uuid();
  u_head uuid := gen_random_uuid();
  u_headb uuid := gen_random_uuid();
  u_x1 uuid := gen_random_uuid();
  d_a uuid := gen_random_uuid();
  d_b uuid := gen_random_uuid();
  c_int uuid := gen_random_uuid();
  c_draft uuid := gen_random_uuid();
  r_owner uuid; r_admin uuid; r_head uuid; r_staff uuid; r_op uuid;
  f_staff uuid := gen_random_uuid();
  f_custom uuid := gen_random_uuid();
  d_new uuid := gen_random_uuid();
  payload jsonb;
begin
  -- ===== Fixtures (trusted service context)
  select id into r_owner from public.roles where key = 'owner';
  select id into r_admin from public.roles where key = 'school_admin';
  select id into r_head from public.roles where key = 'department_head';
  select id into r_staff from public.roles where key = 'staff';
  select id into r_op from public.roles where key = 'operator';

  insert into auth.users (id, aud, role, email)
  select x, 'authenticated', 'authenticated', 't_' || x || '@test.local'
  from unnest(array[u_owner, u_admin, u_teacher, u_head, u_headb, u_x1]) as x;
  insert into public.profiles (id, full_name, email)
  select x, 'User ' || left(x::text, 6), 't_' || x || '@test.local'
  from unnest(array[u_owner, u_admin, u_teacher, u_head, u_headb, u_x1]) as x;
  insert into public.departments (id, name_ar, name_en) values (d_a, 'أ', 'A'), (d_b, 'ب', 'B');

  insert into public.role_permissions (role_id, permission_key)
  select r_admin, k from unnest(array['users.manage', 'circular.create', 'circular.publish']) as k;
  insert into public.role_permissions (role_id, permission_key) values (r_head, 'circular.respond');

  insert into public.user_role_assignments (user_id, role_id, department_id) values
    (u_owner, r_owner, null), (u_admin, r_admin, null), (u_x1, r_op, null),
    (u_teacher, r_staff, d_a), (u_head, r_head, d_a), (u_headb, r_head, d_b);

  insert into public.circulars (id, ref_number, title, body, created_by, status, visibility) values
    (c_int, 'T-INT', 'internal', 'b', u_admin, 'published', 'internal'),
    (c_draft, 'T-DRAFT', 'draft', 'b', u_admin, 'draft', 'internal');
  insert into public.circular_targets (circular_id, department_id) values (c_int, d_a), (c_draft, d_a);

  -- ===== submit_circular_response
  perform t_tmp.as_user(u_head);
  perform t_tmp.expect(not t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'acknowledgement','acknowledged')$q$, c_int, d_a)), 'department head can respond');
  perform t_tmp.expect(not t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'acknowledgement','acknowledged')$q$, c_int, d_a)), 'an acknowledgement can be repeated');
  perform t_tmp.expect(not t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'approval','approved')$q$, c_int, d_a)), 'an acknowledgement can be upgraded to a decision');
  perform t_tmp.expect(t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'approval','rejected','no')$q$, c_int, d_a)), 'a final decision cannot be revised when revisions are off');
  perform t_tmp.as_user(u_teacher);
  perform t_tmp.expect(t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'acknowledgement','acknowledged')$q$, c_int, d_a)), 'a user without circular.respond cannot respond');
  perform t_tmp.as_user(u_headb);
  perform t_tmp.expect(t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'acknowledgement','acknowledged')$q$, c_int, d_a)), 'another department cannot respond');
  perform t_tmp.as_user(u_head);
  perform t_tmp.expect(t_tmp.fails(format($q$select public.submit_circular_response(%L,%L,'acknowledgement','acknowledged')$q$, c_draft, d_a)), 'a draft circular cannot be answered');
  perform t_tmp.as_service();
  perform t_tmp.expect(t_tmp.cnt(format('select 1 from public.circular_responses where circular_id = %L', c_int)) = 3, 'history keeps three response rows');
  perform t_tmp.expect(t_tmp.cnt(format('select 1 from public.circular_responses where circular_id = %L and is_latest', c_int)) = 1, 'exactly one latest response');

  -- ===== dissociate_school_user
  perform t_tmp.as_user(u_teacher);
  perform t_tmp.expect(t_tmp.fails(format('select public.dissociate_school_user(%L)', u_x1)), 'a user without users.manage cannot remove users');
  perform t_tmp.as_user(u_admin);
  perform t_tmp.expect(t_tmp.fails(format('select public.dissociate_school_user(%L)', u_admin)), 'cannot remove yourself');
  perform t_tmp.expect(t_tmp.fails(format('select public.dissociate_school_user(%L)', u_owner)), 'cannot remove the owner');
  perform t_tmp.expect(t_tmp.fails(format('select public.dissociate_school_user(%L)', gen_random_uuid())), 'unknown user is rejected');
  perform t_tmp.expect(not t_tmp.fails(format('select public.dissociate_school_user(%L)', u_x1)), 'a user manager can remove a user');
  perform t_tmp.as_service();
  perform t_tmp.expect(t_tmp.cnt(format($q$select 1 from public.profiles where id = %L and not is_active and department_id is null$q$, u_x1)) = 1, 'removed user is deactivated');
  perform t_tmp.expect(t_tmp.cnt(format('select 1 from public.user_role_assignments where user_id = %L', u_x1)) = 0, 'removed user has no role');

  -- ===== restore_backup
  perform t_tmp.expect(t_tmp.fails(format($q$select public.restore_backup('{}'::jsonb, %L)$q$, u_admin)), 'only the owner can restore');
  perform t_tmp.expect(t_tmp.fails(format($q$select public.restore_backup('{"audit_logs":[]}'::jsonb, %L)$q$, u_owner)), 'tables outside the contract are rejected');
  perform t_tmp.expect(t_tmp.fails(format($q$select public.restore_backup(jsonb_build_object('profiles', jsonb_build_array(jsonb_build_object('id', %L::text, 'full_name', 'x', 'email', 'x@test.local'))), %L)$q$, u_owner, u_owner)), 'a backup cannot touch an owner account');
  perform t_tmp.expect(t_tmp.fails(format($q$select public.restore_backup(jsonb_build_object('role_permissions', jsonb_build_array(jsonb_build_object('role_id', %L::text, 'permission_key', 'audit.view'))), %L)$q$, gen_random_uuid(), u_owner)), 'permissions for an unknown role are rejected');
  perform t_tmp.expect(t_tmp.fails(format($q$select public.restore_backup(jsonb_build_object('roles', jsonb_build_array(jsonb_build_object('id', %L::text, 'key', 'owner', 'name_ar', 'x', 'name_en', 'x')), 'user_role_assignments', jsonb_build_array(jsonb_build_object('user_id', %L::text, 'role_id', %L::text))), %L)$q$, r_owner, u_x1, r_owner, u_owner)), 'an owner assignment in a backup is rejected');

  payload := jsonb_build_object(
    'schools', jsonb_build_array(jsonb_build_object('id', gen_random_uuid(), 'name_ar', 'م', 'name_en', 'Restored School', 'slug', 'restored')),
    'school_settings', jsonb_build_array(jsonb_build_object('academic_year', '2026/2027')),
    'departments', jsonb_build_array(jsonb_build_object('id', d_new, 'name_ar', 'ق', 'name_en', 'Restored', 'head_profile_id', u_head)),
    'roles', jsonb_build_array(
      jsonb_build_object('id', f_staff, 'key', 'staff', 'name_ar', 'موظف', 'name_en', 'Staff Restored', 'is_system', false),
      jsonb_build_object('id', f_custom, 'key', 'electrician', 'name_ar', 'كهربائي', 'name_en', 'Electrician')),
    'role_permissions', jsonb_build_array(
      jsonb_build_object('role_id', f_staff, 'permission_key', 'audit.view'),
      jsonb_build_object('role_id', f_custom, 'permission_key', 'maintenance.update'))
  );
  perform t_tmp.expect(not t_tmp.fails(format('select public.restore_backup(%L::jsonb, %L)', payload::text, u_owner)), 'a valid backup restores');
  perform t_tmp.expect(t_tmp.cnt('select 1 from public.schools') = 1, 'still exactly one school');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.schools where name_en = 'Restored School'$q$) = 1, 'the school row was replaced in place');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.school_settings where academic_year = '2026/2027'$q$) = 1, 'school settings were replaced in place');
  perform t_tmp.expect(t_tmp.cnt(format('select 1 from public.departments where id = %L and head_profile_id = %L', d_new, u_head)) = 1, 'department head link restored after profiles');
  perform t_tmp.expect(t_tmp.cnt(format($q$select 1 from public.roles where id = %L and name_en = 'Staff Restored' and is_system$q$, r_staff)) = 1, 'system role kept its id and flags, name updated');
  perform t_tmp.expect(t_tmp.cnt(format($q$select 1 from public.role_permissions where role_id = %L and permission_key = 'audit.view'$q$, r_staff)) = 1, 'permissions were remapped onto the existing system role');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.role_permissions rp join public.roles r on r.id = rp.role_id where r.key = 'electrician' and rp.permission_key = 'maintenance.update'$q$) = 1, 'custom role and its permissions restored');
  perform t_tmp.expect(t_tmp.cnt($q$select 1 from public.roles where key = 'owner' and is_locked and is_system$q$) = 1, 'owner role untouched');

  perform t_tmp.as_service();
end $$;

select 'phase 2c function tests passed' as result;
rollback;
