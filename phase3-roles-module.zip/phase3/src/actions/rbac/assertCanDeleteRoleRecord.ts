import type { SupabaseClient } from "@supabase/supabase-js";
import { mapDatabaseError } from "@/lib/errors/mapDatabaseError";

/**
 * Only the owner deletes roles, and only custom roles with no users.
 * System roles and the locked owner role are permanent. The database enforces
 * the same rules; this check returns a friendly message first.
 */
export async function assertCanDeleteRoleRecord(
  supabase: SupabaseClient,
  roleId: string,
  isOwner = false,
): Promise<{ allowed: boolean; error?: string }> {
  const { data: role, error: roleError } = await supabase
    .from("roles")
    .select("id, key, is_system, is_locked")
    .eq("id", roleId)
    .maybeSingle();

  if (roleError) {
    throw mapDatabaseError(roleError);
  }

  if (!role) {
    return { allowed: false, error: "Role not found" };
  }

  if (!isOwner) {
    return { allowed: false, error: "Only the owner can delete roles" };
  }

  if (role.is_locked || role.key === "owner") {
    return { allowed: false, error: "Cannot delete the owner role" };
  }

  if (role.is_system) {
    return { allowed: false, error: "System roles cannot be deleted" };
  }

  const { data: assignments, error: assignError } = await supabase
    .from("user_role_assignments")
    .select("id")
    .eq("role_id", roleId)
    .limit(1);

  if (assignError) {
    throw mapDatabaseError(assignError);
  }

  if (assignments && assignments.length > 0) {
    return {
      allowed: false,
      error:
        "Cannot delete role assigned to active users. Please reassign or delete assigned users first.",
    };
  }

  return { allowed: true };
}
